Copie a pasta `src` deste zip por cima da `src` do seu projeto (aceite substituir).
O README.md atualizado vai na raiz do projeto. Nenhum pacote novo é necessário.
Depois: npx expo start --clear
Para usar: Mais > Configurações > Conteúdo 18+ > ligar e confirmar a idade.
