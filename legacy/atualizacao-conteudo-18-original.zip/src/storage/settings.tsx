import { createContext, ReactNode, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Configurações do app (valem para o aparelho todo). Chave: "settings_v1".
type Saved = { autoplay: boolean; adultEnabled: boolean; blurAdult: boolean };

type SettingsValue = Saved & {
  setAutoplay: (value: boolean) => void;
  setAdultEnabled: (value: boolean) => void;
  setBlurAdult: (value: boolean) => void;
};

const KEY = 'settings_v1';
const SettingsContext = createContext<SettingsValue | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [autoplay, setAutoplayState] = useState(true);
  const [adultEnabled, setAdultEnabledState] = useState(false); // desligado por padrão
  const [blurAdult, setBlurAdultState] = useState(true); // capas 18+ desfocadas por padrão

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (raw) {
          const saved = JSON.parse(raw);
          if (typeof saved.autoplay === 'boolean') setAutoplayState(saved.autoplay);
          if (typeof saved.adultEnabled === 'boolean') setAdultEnabledState(saved.adultEnabled);
          if (typeof saved.blurAdult === 'boolean') setBlurAdultState(saved.blurAdult);
        }
      } catch (e) {
        console.log('[Config] falha ao ler', String(e));
      }
    })();
  }, []);

  function save(next: Saved) {
    AsyncStorage.setItem(KEY, JSON.stringify(next)).catch((e) =>
      console.log('[Config] falha ao salvar', String(e))
    );
  }

  function setAutoplay(value: boolean) {
    setAutoplayState(value);
    save({ autoplay: value, adultEnabled, blurAdult });
  }
  function setAdultEnabled(value: boolean) {
    setAdultEnabledState(value);
    save({ autoplay, adultEnabled: value, blurAdult });
  }
  function setBlurAdult(value: boolean) {
    setBlurAdultState(value);
    save({ autoplay, adultEnabled, blurAdult: value });
  }

  return (
    <SettingsContext.Provider
      value={{ autoplay, adultEnabled, blurAdult, setAutoplay, setAdultEnabled, setBlurAdult }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings precisa estar dentro de <SettingsProvider>.');
  return ctx;
}
