import { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import FilterChips, { Filter } from '../components/FilterChips';
import TituloRow from '../components/TituloRow';
import { searchMedia, Titulo } from '../services/anilist';
import { useSettings } from '../storage/settings';
import { colors } from '../theme';

// Tela separada para conteúdo 18+. Só funciona com o recurso ativado em Configurações.
export default function AdultoScreen() {
  const { adultEnabled } = useSettings();

  const [text, setText] = useState('');
  const [debounced, setDebounced] = useState('');
  const [filter, setFilter] = useState<Filter>('TUDO');

  const [items, setItems] = useState<Titulo[]>([]);
  const [page, setPage] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(text.trim()), 500);
    return () => clearTimeout(t);
  }, [text]);

  const type = filter === 'TUDO' ? undefined : filter;
  const query = debounced.length >= 2 ? debounced : undefined;

  const params = useCallback(
    (p: number) => ({
      adult: true,
      type,
      search: query,
      sort: query ? undefined : ['POPULARITY_DESC'],
      perPage: 25,
      page: p,
    }),
    [type, query]
  );

  const loadFirst = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await searchMedia(params(1));
      setItems(res.items);
      setHasNext(res.hasNext);
      setPage(1);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro inesperado.');
    } finally {
      setLoading(false);
    }
  }, [params]);

  useEffect(() => {
    if (adultEnabled) loadFirst();
  }, [loadFirst, adultEnabled]);

  async function loadMore() {
    setLoadingMore(true);
    try {
      const res = await searchMedia(params(page + 1));
      setItems((prev) => {
        const ids = new Set(prev.map((p) => p.id));
        return [...prev, ...res.items.filter((i) => !ids.has(i.id))];
      });
      setHasNext(res.hasNext);
      setPage(page + 1);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro inesperado.');
    } finally {
      setLoadingMore(false);
    }
  }

  if (!adultEnabled) {
    return (
      <View style={styles.blocked}>
        <Text style={styles.blockedTitle}>Conteúdo 18+ desativado</Text>
        <Text style={styles.blockedText}>
          Este recurso é opcional e só pode ser usado por maiores de 18 anos. Ative em Configurações.
        </Text>
        <Pressable style={styles.button} onPress={() => router.replace('/configuracoes')}>
          <Text style={styles.buttonText}>Abrir configurações</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <View style={styles.top}>
        <View style={styles.inputBox}>
          <Ionicons name="search" size={20} color={colors.textMuted} />
          <TextInput
            style={styles.input}
            placeholder="Buscar conteúdo 18+"
            placeholderTextColor={colors.textMuted}
            value={text}
            onChangeText={setText}
            returnKeyType="search"
          />
          {text !== '' && (
            <Pressable hitSlop={10} onPress={() => setText('')}>
              <Ionicons name="close-circle" size={20} color={colors.textMuted} />
            </Pressable>
          )}
        </View>
        <FilterChips value={filter} onChange={setFilter} />
      </View>

      <FlatList
        data={items}
        keyExtractor={(t) => String(t.id)}
        keyboardShouldPersistTaps="handled"
        renderItem={({ item }) => <TituloRow titulo={item} />}
        ListEmptyComponent={
          loading ? (
            <ActivityIndicator style={{ marginTop: 40 }} color={colors.accent} />
          ) : error ? (
            <View style={styles.center}>
              <Text style={styles.message}>{error}</Text>
              <Pressable style={styles.button} onPress={loadFirst}>
                <Text style={styles.buttonText}>Tentar de novo</Text>
              </Pressable>
            </View>
          ) : (
            <Text style={styles.message}>Nenhum resultado.</Text>
          )
        }
        ListFooterComponent={
          hasNext ? (
            <Pressable style={[styles.button, { margin: 16 }]} onPress={loadMore} disabled={loadingMore}>
              {loadingMore ? (
                <ActivityIndicator color={colors.bg} />
              ) : (
                <Text style={styles.buttonText}>Carregar mais</Text>
              )}
            </Pressable>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  top: { padding: 16, gap: 12 },
  inputBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.surface, borderRadius: 24, paddingHorizontal: 14, height: 46 },
  input: { flex: 1, color: colors.text, fontSize: 16 },
  blocked: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  blockedTitle: { color: colors.text, fontSize: 22, fontWeight: '800' },
  blockedText: { color: colors.textMuted, textAlign: 'center' },
  center: { alignItems: 'center', gap: 12, marginTop: 40 },
  message: { color: colors.textMuted, textAlign: 'center', marginTop: 40, paddingHorizontal: 24 },
  button: { backgroundColor: colors.accent, paddingVertical: 12, paddingHorizontal: 24, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: colors.bg, fontWeight: '800' },
});
